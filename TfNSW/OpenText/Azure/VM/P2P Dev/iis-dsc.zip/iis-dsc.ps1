Configuration IISConfig
{
    param ($MachineName)

    Node $MachineName
    {
        #Install the IIS Role
        WindowsFeature IIS {
            Ensure = "Present"
            Name   = "Web-Server"
        }

        WindowsFeature WebRequestMonitor {
            Ensure = "Present"
            Name   = "Web-Request-Monitor"
        }

        WindowsFeature WebDynCompression {
            Ensure = "Present"
            Name   = "Web-Dyn-Compression"
        }

        #Install ASP.NET 4.5
        WindowsFeature ASP {
            Ensure = "Present"
            Name   = "Web-Asp-Net45"
        }

        WindowsFeature ASP35 {
            Ensure = "Present"
            Name   = "Web-Asp-Net"
        }

        WindowsFeature CGI {
            Ensure = "Present"
            Name   = "Web-CGI"
        }

        WindowsFeature WebServerManagementConsole {
            Name   = "Web-Mgmt-Console"
            Ensure = "Present"
        }
    }
} 