Configuration IISConfig
{
    param ($MachineName)

    Import-DscResource -ModuleName xStorage, xPendingReboot

    Node $MachineName
    {
      
      
        ###Loops through each drive letter and attaches it
        #ForEach ($item in $Node.StandAloneDisks) {

        #    xWaitforDisk "WaitforDisk_$($Node.StandAloneDisks.Indexof($item))" {
        #        DiskID           = $item.WaitDiskNumber
        #        RetryIntervalSec = $item.RetryInterval
        #        RetryCount       = $item.RetryCount
        #    }
    
        #    xDisk "Disk_$($Node.StandAloneDisks.Indexof($item))" {
        #        DiskID             = $item.disknumber
        #        Driveletter        = $item.driveletter
        #        FSLabel            = $item.fslabel
        #        AllocationUnitSize = 64kb
        #    }
        #}
      
        #xWaitforDisk Disk2
        #  {
        #      DiskNumber = 2
        #      RetryIntervalSec = 20
        #      RetryCount = 30
        #  }

        #  xDisk ADDataDisk {
        #      DiskNumber = 2
        #      DriveLetter = "F"
        #      DependsOn = "[xWaitForDisk]Disk2"
        #  }
      
      
        #Install the IIS Role
        WindowsFeature IIS {
            Ensure = "Present"
            Name   = "Web-Server"
        }

        WindowsFeature WebRequestMonitor {
            Ensure = "Present"
            Name   = "Web-Request-Monitor"
        }

        WindowsFeature WebDynCompression {
            Ensure = "Present"
            Name   = "Web-Dyn-Compression"
        }

        #Install ASP.NET 4.5
        WindowsFeature ASP {
            Ensure = "Present"
            Name   = "Web-Asp-Net45"
        }

        WindowsFeature ASP35 {
            Ensure = "Present"
            Name   = "Web-Asp-Net"
        }

        WindowsFeature CGI {
            Ensure = "Present"
            Name   = "Web-CGI"
        }

        WindowsFeature WebServerManagementConsole {
            Name   = "Web-Mgmt-Console"
            Ensure = "Present"
        }

        WindowsFeature WebServerManagementConsoleCompat {
            Name   = "Web-Mgmt-Compat"
            Ensure = "Present"
        }

        
    }
} 
