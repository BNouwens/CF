Configuration DiskConfig
{
    param ($MachineName)

    Import-DscResource -ModuleName xStorage, xPendingReboot, PSDesiredStateConfiguration 

    Node $MachineName
    {
      
      
        ###Loops through each drive letter and attaches it
        ForEach ($item in $MachineName.StandAloneDisks) {

            xWaitforDisk "WaitforDisk_$($MachineName.StandAloneDisks.Indexof($item))" {
                DiskID           = $item.WaitDiskNumber
                RetryIntervalSec = $item.RetryInterval
                RetryCount       = $item.RetryCount
            }
    
            xDisk "Disk_$($MachineName.StandAloneDisks.Indexof($item))" {
                DiskID             = $item.disknumber
                Driveletter        = $item.driveletter
                FSLabel            = $item.fslabel
                AllocationUnitSize = 64kb
            }
        }
      <#
        xWaitforDisk Disk2
          {
              DiskNumber = 2
              RetryIntervalSec = 20
              RetryCount = 30
          }

          xDisk ADDataDisk {
              DiskNumber = 2
              DriveLetter = "F"
              DependsOn = "[xWaitForDisk]Disk2"
          }
      #>
      
    }
} 
