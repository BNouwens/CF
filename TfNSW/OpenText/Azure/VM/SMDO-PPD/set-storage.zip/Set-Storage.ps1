Configuration disks
{
  $DriveLetters = 'FGHIJKLMNOPQSRT'
  Import-DscResource -ModuleName xStorage, xPendingReboot, PSDesiredStateConfiguration 

  param ($MachineName)

  Node $MachineName
  {
    Get-Disk | Where-Object {$_.NumberOfPartitions -lt 1} | Foreach-Object {
      Write-Verbose "disk($($_.Number))" -Verbose
      xDisk "disk($($_.Number))"
      {
        DriveLetter = $DriveLetters[$_.Number]
        DiskNumber = $_.Number
        FSFormat = 'NTFS'        
      }
    }
  }
}